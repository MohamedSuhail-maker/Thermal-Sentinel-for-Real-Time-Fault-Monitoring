import React from 'react';
import { TemperatureChart } from './TemperatureChart';
import { format } from 'date-fns';

interface Props {
  data: { timestamp: number; value: number }[];
}

export function History({ data }: Props) {
  const dailyAverage = data.reduce((sum, item) => sum + item.value, 0) / data.length;
  const maxTemp = Math.max(...data.map(item => item.value));
  const minTemp = Math.min(...data.map(item => item.value));

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Temperature History</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-900 p-4 rounded-lg">
          <p className="text-sm text-gray-400">Daily Average</p>
          <p className="text-2xl font-bold text-blue-400">{dailyAverage.toFixed(1)}°C</p>
        </div>
        <div className="bg-gray-900 p-4 rounded-lg">
          <p className="text-sm text-gray-400">Daily Maximum</p>
          <p className="text-2xl font-bold text-red-400">{maxTemp.toFixed(1)}°C</p>
        </div>
        <div className="bg-gray-900 p-4 rounded-lg">
          <p className="text-sm text-gray-400">Daily Minimum</p>
          <p className="text-2xl font-bold text-green-400">{minTemp.toFixed(1)}°C</p>
        </div>
      </div>

      <div className="bg-gray-900 rounded-lg p-6">
        <div className="h-96">
          <TemperatureChart data={data} />
        </div>
      </div>

      <div className="bg-gray-900 rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Temperature Log</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-gray-400">
                <th className="p-2">Timestamp</th>
                <th className="p-2">Temperature</th>
              </tr>
            </thead>
            <tbody>
              {[...data].reverse().map((item) => (
                <tr key={item.timestamp} className="border-t border-gray-800">
                  <td className="p-2">{format(item.timestamp, 'MMM d, yyyy HH:mm:ss')}</td>
                  <td className="p-2">{item.value.toFixed(1)}°C</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}