import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { ThermalHeatmap } from './components/ThermalHeatmap';
import { TemperatureChart } from './components/TemperatureChart';
import { AlertList } from './components/AlertList';
import { LiveMonitor } from './components/LiveMonitor';
import { History } from './components/History';
import type { ThermalData, Alert, View } from './types';

// Simulate thermal data generation
function generateThermalData(): ThermalData {
  const size = 64;
  const temperature = Array(size).fill(0).map(() => 
    Array(size).fill(0).map(() => 20 + Math.random() * 10)
  );
  
  const allTemps = temperature.flat();
  return {
    timestamp: Date.now(),
    temperature,
    maxTemp: Math.max(...allTemps),
    minTemp: Math.min(...allTemps),
    avgTemp: allTemps.reduce((a, b) => a + b, 0) / (size * size),
  };
}

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [thermalData, setThermalData] = useState<ThermalData>(generateThermalData());
  const [tempHistory, setTempHistory] = useState<{ timestamp: number; value: number }[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const newData = generateThermalData();
      setThermalData(newData);
      
      setTempHistory(prev => [
        ...prev.slice(-30),
        { timestamp: newData.timestamp, value: newData.avgTemp }
      ]);

      if (newData.maxTemp > 28) {
        setAlerts(prev => [{
          id: Date.now().toString(),
          timestamp: Date.now(),
          message: `High temperature detected: ${newData.maxTemp.toFixed(1)}°C`,
          type: newData.maxTemp > 30 ? 'critical' : 'warning'
        }, ...prev.slice(0, 4)]);

        // Here you would integrate with a push notification service
        if (newData.maxTemp > 30) {
          // Example: Send push notification
          // await sendPushNotification({
          //   title: 'Critical Temperature Alert',
          //   body: `Temperature exceeded ${newData.maxTemp.toFixed(1)}°C`,
          //   priority: 'high'
          // });
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const renderContent = () => {
    switch (currentView) {
      case 'live-monitor':
        return <LiveMonitor data={thermalData} />;
      case 'history':
        return <History data={tempHistory} />;
      case 'alerts':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Alert History</h2>
            <AlertList alerts={alerts} showAll />
          </div>
        );
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="bg-gray-900 rounded-lg p-4">
                <h2 className="text-2xl font-bold mb-2">Thermal Monitor</h2>
                <p className="text-gray-400">Real-time thermal imaging system</p>
                <div className="mt-4 grid grid-cols-3 gap-4">
                  <div className="bg-gray-800 p-4 rounded-lg">
                    <p className="text-sm text-gray-400">Max Temp</p>
                    <p className="text-2xl font-bold text-red-400">
                      {thermalData.maxTemp.toFixed(1)}°C
                    </p>
                  </div>
                  <div className="bg-gray-800 p-4 rounded-lg">
                    <p className="text-sm text-gray-400">Min Temp</p>
                    <p className="text-2xl font-bold text-blue-400">
                      {thermalData.minTemp.toFixed(1)}°C
                    </p>
                  </div>
                  <div className="bg-gray-800 p-4 rounded-lg">
                    <p className="text-sm text-gray-400">Avg Temp</p>
                    <p className="text-2xl font-bold text-green-400">
                      {thermalData.avgTemp.toFixed(1)}°C
                    </p>
                  </div>
                </div>
              </div>
              <ThermalHeatmap data={thermalData} />
            </div>
            <div className="space-y-6">
              <TemperatureChart data={tempHistory} />
              <AlertList alerts={alerts} />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex bg-gray-800 min-h-screen text-white">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;