import React from 'react';
import { LayoutDashboard, Thermometer as ThermometerHot, History, Bell } from 'lucide-react';
import type { View } from '../types';

interface Props {
  currentView: View;
  onViewChange: (view: View) => void;
}

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard' as View },
  { icon: ThermometerHot, label: 'Live Monitor', id: 'live-monitor' as View },
  { icon: History, label: 'History', id: 'history' as View },
  { icon: Bell, label: 'Alerts', id: 'alerts' as View },
];

export function Sidebar({ currentView, onViewChange }: Props) {
  return (
    <div className="w-64 bg-gray-900 h-screen p-4 flex flex-col">
      <div className="flex items-center gap-3 px-2 py-4">
        <ThermometerHot className="w-8 h-8 text-blue-500" />
        <h1 className="text-xl font-bold text-white">ThermalView</h1>
      </div>
      
      <nav className="flex-1 mt-8">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  currentView === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}