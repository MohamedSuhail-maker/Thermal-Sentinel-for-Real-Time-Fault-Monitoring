import React, { useEffect, useRef } from 'react';
import type { ThermalData } from '../types';

interface Props {
  data: ThermalData;
}

export function ThermalHeatmap({ data }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const width = 64;
    const height = 64;
    const imageData = ctx.createImageData(width, height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const temp = data.temperature[y][x];
        const normalizedTemp = (temp - data.minTemp) / (data.maxTemp - data.minTemp);
        
        // Convert temperature to RGB (blue to red gradient)
        const r = Math.floor(normalizedTemp * 255);
        const b = Math.floor((1 - normalizedTemp) * 255);
        const g = 0;

        const index = (y * width + x) * 4;
        imageData.data[index] = r;
        imageData.data[index + 1] = g;
        imageData.data[index + 2] = b;
        imageData.data[index + 3] = 255;
      }
    }

    ctx.putImageData(imageData, 0, 0);
  }, [data]);

  return (
    <div className="relative bg-gray-900 rounded-lg p-4">
      <h3 className="text-lg font-semibold text-gray-100 mb-4">Thermal Heatmap</h3>
      <canvas
        ref={canvasRef}
        width={64}
        height={64}
        className="w-full aspect-square rounded-lg"
        style={{ imageRendering: 'pixelated' }}
      />
      <div className="mt-4 flex justify-between text-sm text-gray-400">
        <span>{data.minTemp.toFixed(1)}°C</span>
        <span>{data.maxTemp.toFixed(1)}°C</span>
      </div>
    </div>
  );
}