import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';
import type { Alert } from '../types';
import { format } from 'date-fns';

interface Props {
  alerts: Alert[];
  showAll?: boolean;
}

export function AlertList({ alerts, showAll }: Props) {
  const displayAlerts = showAll ? alerts : alerts.slice(0, 5);

  return (
    <div className="bg-gray-900 rounded-lg p-4">
      <h3 className="text-lg font-semibold text-gray-100 mb-4">
        {showAll ? 'All Alerts' : 'Recent Alerts'}
      </h3>
      <div className="space-y-2">
        {displayAlerts.map(alert => (
          <div
            key={alert.id}
            className={`flex items-center gap-3 p-3 rounded-lg ${
              alert.type === 'critical'
                ? 'bg-red-950 text-red-200'
                : alert.type === 'warning'
                ? 'bg-yellow-950 text-yellow-200'
                : 'bg-blue-950 text-blue-200'
            }`}
          >
            {alert.type === 'critical' || alert.type === 'warning' ? (
              <AlertTriangle className="w-5 h-5" />
            ) : (
              <Info className="w-5 h-5" />
            )}
            <div className="flex-1">
              <p className="text-sm">{alert.message}</p>
              <p className="text-xs opacity-75">
                {format(alert.timestamp, 'MMM d, yyyy HH:mm:ss')}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}