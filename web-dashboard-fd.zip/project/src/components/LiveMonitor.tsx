import React from 'react';
import type { ThermalData } from '../types';
import { ThermalHeatmap } from './ThermalHeatmap';

interface Props {
  data: ThermalData;
}

export function LiveMonitor({ data }: Props) {
  return (
    <div className="space-y-6">
      <div className="bg-gray-900 rounded-lg p-6">
        <h2 className="text-2xl font-bold mb-4">Live Thermal Monitor</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ThermalHeatmap data={data} />
          <div className="space-y-4">
            <div className="bg-gray-800 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">Current Readings</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-400">Maximum Temperature</p>
                  <p className="text-xl font-bold text-red-400">{data.maxTemp.toFixed(1)}°C</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Minimum Temperature</p>
                  <p className="text-xl font-bold text-blue-400">{data.minTemp.toFixed(1)}°C</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Average Temperature</p>
                  <p className="text-xl font-bold text-green-400">{data.avgTemp.toFixed(1)}°C</p>
                </div>
              </div>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Device Status</h3>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <p className="text-green-400">your machine is healthy</p>
              </div>
              <p className="text-sm text-gray-400 mt-2">Last Update: Just now</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}