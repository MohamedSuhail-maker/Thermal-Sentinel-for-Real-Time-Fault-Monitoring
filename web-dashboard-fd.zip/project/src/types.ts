export interface ThermalData {
  timestamp: number;
  temperature: number[][];
  maxTemp: number;
  minTemp: number;
  avgTemp: number;
}

export interface Alert {
  id: string;
  timestamp: number;
  message: string;
  type: 'warning' | 'critical' | 'info';
}

export type View = 'dashboard' | 'live-monitor' | 'history' | 'alerts';